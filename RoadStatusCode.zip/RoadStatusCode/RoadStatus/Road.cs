﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace RoadStatus
{
    /// <summary>
    /// Road model to capture data from Road API Json response
    /// </summary>
    public class Road
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("statusSeverity")]
        public string StatusSeverity { get; set; }

        [JsonProperty("statusSeverityDescription")]
        public string StatusSeverityDescription { get; set; }

        [JsonProperty("bounds")]
        public string Bounds { get; set; }

        [JsonProperty("envelope")]
        public string Envelope { get; set; }

        [JsonProperty("url")]
        public string Url { get; set; }
    }

    /// <summary>
    /// Define Exit code Enum for Road status response
    /// </summary>
    public enum ExitCode
    {
        Valid = 0,
        Invalid = 1
    }
}