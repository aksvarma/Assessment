﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.IO;
using System.Threading.Tasks;
using System.Web;
using Newtonsoft.Json;
using System.Linq;

namespace RoadStatus
{
    public class FetchRoadStatus
    {
        public List<Road> roadObj;
        public Task<HttpResponseMessage> tflRoadResponse;

        /// <summary>
        /// Get road status based on road name
        /// </summary>
        /// <param name="roadId">Road Id entered by user</param>
        public void GetRoadStatus(string roadId)
        {
            var apiAsyncClient = new HttpClient();

            try
            {
                if (string.IsNullOrEmpty(roadId))
                {
                    Environment.Exit((int)ExitCode.Invalid);
                }

                var tflRoadrequest = CreateRequest(roadId);

                //Call the tfl API to get Road status
                tflRoadResponse = apiAsyncClient.SendAsync(tflRoadrequest);

                //Check for successful status to define output
                if (tflRoadResponse.Result.IsSuccessStatusCode)
                {
                    var responseMessage = tflRoadResponse.Result.Content.ReadAsStringAsync();
                    //Deserialise response to road object
                    roadObj = JsonConvert.DeserializeObject<List<Road>>(responseMessage.Result);

                    if (roadObj[0] is Road)
                    {
                        Console.WriteLine("The status of the {0} is as follows :", roadObj[0].DisplayName);
                        Console.WriteLine("Road Status is {0}", roadObj[0].StatusSeverity);
                        Console.WriteLine("Road Status Description is {0}", roadObj[0].StatusSeverityDescription);
                    }

                    //Set the exit Code for Valid response
                    Environment.ExitCode = (int)ExitCode.Valid;
                }
                else
                {
                    Console.WriteLine("{0} is not a valid road", roadId);
                    //Set the exit code for Invalid response
                    Environment.ExitCode = (int)ExitCode.Invalid;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error Occured!! Please retry with valid road id.");
            }
        }

        /// <summary>
        /// Create HttpRequest to get the Road status
        /// </summary>
        /// <param name="roadId">Road Id entered by user</param>
        /// <returns></returns>
        private HttpRequestMessage CreateRequest(string roadId)
        {
            // Create the request to the Get Road status
            var builder = new UriBuilder()
            {
                Scheme = "https",
                Host = "api.tfl.gov.uk/Road",
                Path = roadId
            };

            //new UriBuilder(tflUrl + roadId);
            var query = HttpUtility.ParseQueryString(builder.Query);
            query["app_id"] = File.ReadLines(@"DeveloperKey.txt").First().Split(':')[1].Trim();
            query["app_key"] = File.ReadLines(@"DeveloperKey.txt").ElementAtOrDefault(1).Split(':')[1].Trim();
            builder.Query = query.ToString();
            string url = builder.ToString();
            
            var request = new HttpRequestMessage(HttpMethod.Get, url);

            return request;
        }
    }
}
