﻿using System;
using System.Net.Http.Headers;
using System.Text;


namespace RoadStatus
{
    public class StartUp
    {
        /// <summary>
        /// Start up method for console app
        /// </summary>
        /// <param name="roadId">Road Id entered by user</param>
        public static void Main(string[] roadId)
        {
            string roadlineId = string.Empty;
            if (roadId.Length == 0)
            {
                Console.WriteLine("Please enter Road Id :\n");
                roadlineId = Console.ReadLine();
            }
            var fetchRoadStatus = new FetchRoadStatus();
            //Pass the road name entered by user to fetch the road status
            fetchRoadStatus.GetRoadStatus(roadId.Length == 0 ? roadlineId : roadId[0]);        
        }        
    }
}
