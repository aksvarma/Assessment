using System;
using NUnit.Framework;
using RoadStatus;

namespace RoadStatusTest
{
    public class RoadStatusTest
    {
        FetchRoadStatus rsObj;

        [Test]
        public void ValidRoad()
        {
            //Arrange
            rsObj = new FetchRoadStatus();

            //Act
            rsObj.GetRoadStatus("A2");

            //Assert
            Assert.True(rsObj.roadObj.Count == 1);
            Assert.True(rsObj.roadObj[0].DisplayName == "A2");
            Assert.True(rsObj.tflRoadResponse.Result.IsSuccessStatusCode);
            Assert.True(Environment.ExitCode == 0);
        }

        [Test]
        public void InValidRoad()
        {
            //Arrange
            rsObj = new FetchRoadStatus();

            //Act
            rsObj.GetRoadStatus("L300");

            //Assert
            Assert.True(rsObj.roadObj == null);
            Assert.False(rsObj.tflRoadResponse.Result.IsSuccessStatusCode);
            Assert.False(Environment.ExitCode == 0);
        }
    }
}